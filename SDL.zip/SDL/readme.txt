directory: SDL-1.2.13 renamed to SDL

creating by combining:
	SDL-devel-1.2.13-VC8.zip
	SDL_ttf-devel-2.0.9-VC8.zip 
